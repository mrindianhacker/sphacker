﻿using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Login_and_Registration_form
{
    public partial class frmRegister : Form
    {
        public frmRegister()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            String name = txtusername.Text;

            if (name == "" || !IsValidName(name))
                MessageBox.Show("Username is not valid", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (txtPassword.Text != txtComPassword.Text)
                MessageBox.Show("Password did not match", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (txtPassword.Text == "" || txtComPassword.Text == "")
                MessageBox.Show("Password is empty", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
                db();
        }

        private void db()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\C#\Login and Registration form\Login and Registration form\Database2.mdf;Integrated Security=True");

            sqlCon.Open();

            string query = "INSERT INTO [Table] (Username, Password) VALUES (@Username, @Password)";

            SqlCommand sqlCmd = new SqlCommand(query, sqlCon);

            sqlCmd.Parameters.AddWithValue("@Username", txtusername.Text);
            sqlCmd.Parameters.AddWithValue("@Password", txtPassword.Text);

            sqlCmd.ExecuteNonQuery();

            MessageBox.Show("Your data inseerted successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string name = txtusername.Text;
        }
        private bool IsValidName(string name)
        {
            Regex regex = new Regex("^[A-Z _a-z]+$");
            return regex.IsMatch(name);
        }
        private void CheckbxShowPas_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckbxShowPas.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtComPassword.PasswordChar = '\0';
            }
        }
        private void label6_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }
        private void label5_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }
    }
}