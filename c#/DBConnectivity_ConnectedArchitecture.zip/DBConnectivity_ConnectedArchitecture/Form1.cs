﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBConnectivity_ConnectedArchitecture
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            txtid.Enabled = true;
            txtnm.Enabled = true;
            txtmobile.Enabled = true;
            cmbcity.Enabled = true;
            panel1.Enabled = true;
            panel2.Enabled = true;
            btnsave.Enabled = true;
            btnadd.Enabled = false;
            txtid.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=DESKTOP-4MKKV3G;Initial Catalog=employee;Integrated Security=True");
            con.Open();
            getdata();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if(txtid.Text==""||txtnm.Text==""||txtmobile.Text==""||cmbcity.SelectedIndex==-1)
            {
                MessageBox.Show("Please Enter Value into the Field",
                     "Blank Record", MessageBoxButtons.OK,
                      MessageBoxIcon.Warning);
            }
            else
            {
                cmd = new SqlCommand("select emp_id from tblemployeeDetail where emp_id='" + Convert.ToInt32(txtid.Text) + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Enter Employee Id is All-Ready Exists",
                         "Duplicate Record", MessageBoxButtons.OK,
                          MessageBoxIcon.Exclamation);
                    txtid.Clear();
                    txtid.Focus();
                    dr.Close();
                }
               
                else
                {
                    dr.Close();
                    cmd = new SqlCommand("insert into tblemployeeDetail values('" + Convert.ToInt32(txtid.Text) + "','" + txtnm.Text + "','" + cmbcity.Text + "','" + txtmobile.Text + "','" + (rbtmale.Checked == true ? rbtmale.Text : rbtfemale.Text) + "','" + (rbtactive.Checked == true ? 1 : 0) + "')", con);
                    int res = cmd.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Insert Successfully",
                             "Insert Record", MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
                        getdata();
                        txtid.Clear();
                        txtmobile.Clear();
                        txtnm.Clear();
                        cmbcity.SelectedIndex = -1;
                        rbtactive.Checked = false;
                        rbtdeactive.Checked = false;
                        rbtmale.Checked = false;
                        rbtfemale.Checked = false;
                        btnsave.Enabled = false;
                        btnadd.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error in insert record",
                             "Error", MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
                    }
                }

            }
        }
        public void getdata()
        {
            cmd = new SqlCommand("select * from tblemployeeDetail", con);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["emp_status"].Index && e.Value != null)
            {
                int statusValue = Convert.ToInt32(e.Value);

                e.Value = (statusValue == 1) ? "Active" : "Deactive";
                e.FormattingApplied = true;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex==0)
            {
                int id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString());
                cmd = new SqlCommand("select emp_id,emp_name,emp_city,emp_mobile,emp_gender,emp_status from tblemployeeDetail where emp_id='" + id + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.Read())
                {
                    btnupdate.Visible = true;
                    btnadd.Visible = false;
                    btnsave.Visible = false;
                    txtmobile.Enabled = true;
                    cmbcity.Enabled = true;
                    txtnm.Enabled = true;
                    panel1.Enabled = true;
                    panel2.Enabled = true;
                    txtid.Text = dr.GetValue(0).ToString();
                    txtnm.Text = dr.GetValue(1).ToString();
                    cmbcity.Text = dr.GetValue(2).ToString();
                    txtmobile.Text = dr.GetValue(3).ToString();
                    if (dr.GetValue(4).ToString() == "Male")
                        rbtmale.Checked = true;
                    else
                        rbtfemale.Checked = true;
                    if (Convert.ToInt32(dr.GetValue(5).ToString()) == 1)
                        rbtactive.Checked = true;
                    else
                        rbtdeactive.Checked = true;
                }
                dr.Close();
            }
            else if(e.ColumnIndex==1)
            {
                DialogResult res = MessageBox.Show("Are you sure want to Delete Record?",
                     "Delete", MessageBoxButtons.YesNo,
                      MessageBoxIcon.Question);
                if(res==DialogResult.Yes)
                {
                    int id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString());
                    cmd = new SqlCommand("delete from tblemployeeDetail where emp_id='" + id+"'", con);
                    int result = cmd.ExecuteNonQuery();
                    if(result>0)
                    {
                        MessageBox.Show("Record Delete Successfully", "Delete",
                             MessageBoxButtons.OK, MessageBoxIcon.Information);
                        getdata();
                    }
                }
            }
            else
            {
                MessageBox.Show("Wrong Click", "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtid.Text);
            cmd = new SqlCommand("update tblemployeeDetail set emp_name='" + txtnm.Text + "',emp_city='" + cmbcity.Text + "',emp_mobile='" + txtmobile.Text + "',emp_gender='" + (rbtmale.Checked == true ? "Male" : "Female") + "',emp_status='" + (rbtactive.Checked == true ? 1 : 0) + "' where emp_id='" + id + "'", con);
            int res = cmd.ExecuteNonQuery();
            if(res>0)
            {
                MessageBox.Show("Record Update Successfully", "Update Record",
                     MessageBoxButtons.OK, MessageBoxIcon.Information);
                getdata();
                txtid.Clear();
                txtmobile.Clear();
                txtnm.Clear();
                cmbcity.SelectedIndex = -1;
                rbtmale.Checked = false;
                rbtfemale.Checked = false;
                rbtactive.Checked = false;
                rbtdeactive.Checked = false;
                btnupdate.Visible = false;
                btnadd.Visible = true;
                btnsave.Visible = true;
                btnsave.Enabled = false;
                txtnm.Enabled = false;
                txtmobile.Enabled = false;
                cmbcity.Enabled = false;
                panel1.Enabled = false;
                panel2.Enabled = false;
            }
        }
    }
}
